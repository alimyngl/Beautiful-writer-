
import React, { useState, useEffect, useCallback } from 'react';
import FontSelector from './components/FontSelector';
import CopyButton from './components/CopyButton';
import { PERSIAN_FONTS, ENGLISH_FONTS, DEFAULT_FONT_FAMILY, DEFAULT_TEXT_DIRECTION } from './constants';
import { FontOption, TextDirection } from './types';

const App: React.FC = () => {
  const [text, setText] = useState<string>('این یک متن نمونه برای زیبانویس است. می‌توانید فونت آن را تغییر دهید!');
  const [selectedFontFamily, setSelectedFontFamily] = useState<string>(DEFAULT_FONT_FAMILY);
  const [textDirection, setTextDirection] = useState<TextDirection>(DEFAULT_TEXT_DIRECTION);
  const [activeSelection, setActiveSelection] = useState<'persian' | 'english'>('persian');


  const handleFontSelect = useCallback((font: FontOption) => {
    setSelectedFontFamily(font.family);
    setTextDirection(font.isPersian ? 'rtl' : 'ltr');
    setActiveSelection(font.isPersian ? 'persian' : 'english');
  }, []);
  
  // Apply font and direction to html and body for better overall page feel
  useEffect(() => {
    document.documentElement.dir = textDirection;
    document.body.style.fontFamily = selectedFontFamily; // This will primarily affect UI elements if they don't have specific fonts
  }, [selectedFontFamily, textDirection]);


  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 selection:bg-sky-200 selection:text-sky-900" dir={textDirection}>
      <main className="bg-white/80 backdrop-blur-md shadow-2xl rounded-xl p-6 md:p-10 w-full max-w-3xl space-y-8">
        <header className="text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-500 via-purple-500 to-pink-500">
            زیبانویس آنلاین
          </h1>
          <p className="mt-3 text-lg text-slate-600">
            متن خود را بنویسید، فونت دلخواه خود را انتخاب کنید و به راحتی کپی کنید.
          </p>
        </header>

        <div className="space-y-6">
          {/* Text Area */}
          <div>
            <label htmlFor="main-text-area" className="block text-sm font-medium text-slate-700 mb-1">
              متن شما
            </label>
            <textarea
              id="main-text-area"
              rows={8}
              className="w-full p-4 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-shadow text-lg"
              placeholder="متن خود را اینجا وارد کنید..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              style={{ fontFamily: selectedFontFamily, direction: textDirection }}
              dir={textDirection} // Explicitly set dir for textarea
            />
          </div>

          {/* Font Selectors */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            <FontSelector
              label="انتخاب فونت فارسی"
              fonts={PERSIAN_FONTS}
              selectedFontFamily={activeSelection === 'persian' ? selectedFontFamily : PERSIAN_FONTS[0].family}
              onSelectFont={handleFontSelect}
              isDisabled={false}
            />
            <FontSelector
              label="انتخاب فونت انگلیسی"
              fonts={ENGLISH_FONTS}
              selectedFontFamily={activeSelection === 'english' ? selectedFontFamily : ENGLISH_FONTS[0].family}
              onSelectFont={handleFontSelect}
              isDisabled={false}
            />
          </div>
        </div>
        
        {/* Preview (using a styled div for accurate representation) */}
        <div className="mt-8">
            <h2 className="text-xl font-semibold text-slate-700 mb-2">پیش‌نمایش</h2>
            <div 
              className="w-full p-4 border border-slate-300 rounded-lg bg-slate-50 min-h-[100px] whitespace-pre-wrap break-words text-lg"
              style={{ fontFamily: selectedFontFamily, direction: textDirection }}
              dir={textDirection} // Explicitly set dir for preview
            >
              {text || "پیش‌نمایش متن شما اینجا نمایش داده می‌شود."}
            </div>
        </div>

        {/* Action Button */}
        <div className="mt-8 pt-6 border-t border-slate-200 flex justify-center">
          <CopyButton textToCopy={text} />
        </div>
      </main>
      <footer className="mt-12 text-center text-sm text-slate-500">
        <p>ساخته شده با ❤️ و React</p>
      </footer>
    </div>
  );
};

export default App;
    