
export interface FontOption {
  name: string;
  family: string;
  isPersian: boolean;
}

export type TextDirection = 'rtl' | 'ltr';
    