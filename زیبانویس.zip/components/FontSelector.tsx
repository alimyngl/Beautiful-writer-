
import React from 'react';
import { FontOption } from '../types';

interface FontSelectorProps {
  label: string;
  fonts: FontOption[];
  selectedFontFamily: string;
  onSelectFont: (font: FontOption) => void;
  isDisabled?: boolean;
}

const FontSelector: React.FC<FontSelectorProps> = ({ label, fonts, selectedFontFamily, onSelectFont, isDisabled }) => {
  const handleChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedFont = fonts.find(f => f.family === event.target.value);
    if (selectedFont) {
      onSelectFont(selectedFont);
    }
  };

  return (
    <div className="mb-4 w-full">
      <label htmlFor={label.replace(/\s+/g, '-')} className="block text-sm font-medium text-slate-700 mb-1">
        {label}
      </label>
      <select
        id={label.replace(/\s+/g, '-')}
        value={selectedFontFamily}
        onChange={handleChange}
        disabled={isDisabled}
        className="mt-1 block w-full pl-3 pr-10 py-2.5 text-base border-slate-300 focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm rounded-md shadow-sm disabled:bg-slate-50 disabled:text-slate-500 disabled:border-slate-200 disabled:shadow-none"
        style={{ fontFamily: selectedFontFamily }}
      >
        {fonts.map((font) => (
          <option key={font.family} value={font.family} style={{ fontFamily: font.family }}>
            {font.name}
          </option>
        ))}
      </select>
    </div>
  );
};

export default FontSelector;
    