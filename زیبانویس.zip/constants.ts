
import { FontOption, TextDirection } from './types';

export const PERSIAN_FONTS: FontOption[] = [
  { name: "وزیرمتن (Vazirmatn)", family: "'Vazirmatn', sans-serif", isPersian: true },
  { name: "لاله‌زار (Lalezar)", family: "'Lalezar', cursive", isPersian: true },
  { name: "امیری (Amiri)", family: "'Amiri', serif", isPersian: true },
  { name: "مرکزی تکست (Markazi Text)", family: "'Markazi Text', serif", isPersian: true },
  { name: "نوتو سنس عربی (Noto Sans Arabic)", family: "'Noto Sans Arabic', sans-serif", isPersian: true },
  { name: "تجول (Tajawal)", family: "'Tajawal', sans-serif", isPersian: true },
  { name: "المسیری (El Messiri)", family: "'El Messiri', sans-serif", isPersian: true },
  { name: "شهرازاد جدید (Scheherazade New)", family: "'Scheherazade New', serif", isPersian: true },
  { name: "لیمونادا (Lemonada)", family: "'Lemonada', cursive", isPersian: true },
  { name: "گلزار (Gulzar)", family: "'Gulzar', serif", isPersian: true }, // Nastaliq-like
  { name: "میرزا (Mirza)", family: "'Mirza', cursive", isPersian: true },
  { name: "نوتو نستعلیق اردو (Noto Nastaliq Urdu)", family: "'Noto Nastaliq Urdu', cursive", isPersian: true },
  { name: "بالو بیجان ۲ (Baloo Bhaijaan 2)", family: "'Baloo Bhaijaan 2', cursive", isPersian: true },
  { name: "کوفام (Kufam)", family: "'Kufam', sans-serif", isPersian: true },
  { name: "قاهره (Cairo)", family: "'Cairo', sans-serif", isPersian: true },
];

export const ENGLISH_FONTS: FontOption[] = [
  { name: "Roboto", family: "'Roboto', sans-serif", isPersian: false },
  { name: "Open Sans", family: "'Open Sans', sans-serif", isPersian: false },
  { name: "Lato", family: "'Lato', sans-serif", isPersian: false },
  { name: "Montserrat", family: "'Montserrat', sans-serif", isPersian: false },
  { name: "Oswald", family: "'Oswald', sans-serif", isPersian: false },
  { name: "Raleway", family: "'Raleway', sans-serif", isPersian: false },
  { name: "Poppins", family: "'Poppins', sans-serif", isPersian: false },
  { name: "Noto Sans", family: "'Noto Sans', sans-serif", isPersian: false },
  { name: "Ubuntu", family: "'Ubuntu', sans-serif", isPersian: false },
  { name: "Merriweather", family: "'Merriweather', serif", isPersian: false },
  { name: "Playfair Display", family: "'Playfair Display', serif", isPersian: false },
  { name: "Bebas Neue", family: "'Bebas Neue', sans-serif", isPersian: false },
  { name: "Source Sans 3", family: "'Source Sans 3', sans-serif", isPersian: false }, // Updated from Source Sans Pro
  { name: "PT Sans", family: "'PT Sans', sans-serif", isPersian: false },
  { name: "Lobster", family: "'Lobster', cursive", isPersian: false },
];

export const DEFAULT_FONT_FAMILY = "'Vazirmatn', sans-serif";
export const DEFAULT_TEXT_DIRECTION: TextDirection = 'rtl';
